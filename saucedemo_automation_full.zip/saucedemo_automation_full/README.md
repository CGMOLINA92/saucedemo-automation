# Proyecto de Automatización - Saucedemo + API MercadoLibre
Este proyecto implementa un framework de automatización utilizando `pytest`, `selenium` y `requests` para cumplir con todos los requerimientos de la **Sección 2 - Automatización de Pruebas** del challenge.

---

##  Tecnologías utilizadas

- Python 3.10+
- Pytest
- Selenium WebDriver
- Requests
- Pytest-HTML (para reportes)

---

##  Estructura del Proyecto

```
saucedemo_automation_full/
├── tests/
│   ├── test_login.py              # Pruebas funcionales de login (éxito y error)
│   └── test_departments_api.py    # Prueba de API para Mercado Libre
├── conftest.py                    # Captura de pantalla si falla una prueba
├── pytest.ini                     # Configuración de Pytest + reporte HTML
├── requirements.txt               # Dependencias
├── screenshots/                   # Carpeta donde se guardan screenshots
└── README.md                      # Este archivo
```

---

## ▶️ Instrucciones de uso

### 1. Clonar o descomprimir el proyecto

### 2. Crear y activar un entorno virtual (opcional pero recomendado)

```bash
python -m venv venv
# Activar en Windows
venv\Scripts\activate
# Activar en Mac/Linux
source venv/bin/activate
```

### 3. Instalar dependencias

```bash
pip install -r requirements.txt
```

### 4. Ejecutar las pruebas

```bash
pytest
```

También podés ejecutar con reporte HTML:

```bash
pytest --html=report.html
```

### 5. Ver resultados

-  `report.html`: contiene el detalle de cada prueba ejecutada
-  Carpeta `screenshots/`: se generan capturas si alguna prueba falla

---

##  Usuarios de prueba para https://www.saucedemo.com/

- Usuario válido: `standard_user`
- Usuario bloqueado: `locked_out_user`
- Contraseña válida: `secret_sauce`

---

## ✍️ Autor

Carla Antonella Garcia Molina
