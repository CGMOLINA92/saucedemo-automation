import requests

def test_departments_endpoint_returns_departments():
    url = "https://www.mercadolibre.com.ar/menu/departments"
    response = requests.get(url)

    assert response.status_code == 200, f"Status esperado 200, pero se obtuvo {response.status_code}"

    json_response = response.json()
    assert "departments" in json_response, "La clave 'departments' no está presente en la respuesta"
    assert len(json_response["departments"]) > 0, "No hay departamentos disponibles en la respuesta"
